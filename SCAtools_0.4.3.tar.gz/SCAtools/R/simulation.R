#' Generate data with a directional sufficiency pattern
#'
#' @param n Number of observations.
#' @param intercepts Intercept or vector of intercepts for frontier lines.
#' @param slopes Slope or vector of slopes for frontier lines.
#' @param direction One sufficiency direction: `"HH"`, `"LH"`, `"HL"`, or
#'   `"LL"`.
#' @param distribution.x,distribution.y Marginal distribution, `"uniform"` or
#'   `"normal"`.
#' @param mean.x,mean.y Means for truncated normal distributions.
#' @param sd.x,sd.y Standard deviations for truncated normal distributions.
#' @return A data frame with X condition columns and one Y outcome column.
#' @export
sca_random <- function(
    n,
    intercepts,
    slopes,
    direction = "HH",
    distribution.x = "uniform",
    distribution.y = "uniform",
    mean.x = 0.5,
    mean.y = 0.5,
    sd.x = 0.2,
    sd.y = 0.2) {
  direction <- .sca_validate_direction(direction, 1L)
  corner <- sca_corner(direction)
  data <- NCA::nca_random(
    n = n,
    intercepts = intercepts,
    slopes = slopes,
    corner = corner,
    distribution.x = distribution.x,
    distribution.y = distribution.y,
    mean.x = mean.x,
    mean.y = mean.y,
    sd.x = sd.x,
    sd.y = sd.y
  )
  attr(data, "sca_direction") <- direction
  attr(data, "empty_corner") <- corner
  data
}

#' Estimate power for a directional sufficiency analysis
#'
#' @param n Sample size or vector of sample sizes.
#' @param effect Population empty-space effect size(s).
#' @param slope Frontier slope(s).
#' @param ceiling Frontier method(s).
#' @param direction One sufficiency direction.
#' @param p Significance level.
#' @param distribution.x,distribution.y Marginal distribution(s).
#' @param rep Number of simulated datasets per design cell.
#' @param test.rep Number of permutations in each simulated analysis.
#' @return A data frame of estimated power values with SCA direction metadata.
#' @export
sca_power <- function(
    n = c(20, 50, 100),
    effect = 0.10,
    slope = 1,
    ceiling = "ce_fdh",
    direction = "HH",
    p = 0.05,
    distribution.x = "uniform",
    distribution.y = "uniform",
    rep = 100,
    test.rep = 200) {
  direction <- .sca_validate_direction(direction, 1L)
  corner <- sca_corner(direction)
  result <- NCA::nca_power(
    n = n,
    effect = effect,
    slope = slope,
    ceiling = ceiling,
    corner = corner,
    p = p,
    distribution.x = distribution.x,
    distribution.y = distribution.y,
    rep = rep,
    test.rep = test.rep
  )
  if (!is.null(result)) {
    result$direction <- direction
    result$empty_corner <- corner
  }
  result
}

#' Plot SCA power results
#'
#' @param df_power Data frame returned by [sca_power()].
#' @param x.variable Column mapped to the x axis.
#' @param x.name X-axis label.
#' @param x.min,x.max X-axis limits.
#' @param line.variable Column mapped to line colour.
#' @param line.name Legend title.
#' @return A `ggplot` object.
#' @export
sca_powerplot <- function(
    df_power,
    x.variable = "n",
    x.name = "Sample size",
    x.min = 0,
    x.max = NULL,
    line.variable = "ES",
    line.name = "Effect size") {
  required <- c("power", x.variable, line.variable)
  missing <- setdiff(required, colnames(df_power))
  if (length(missing) > 0L) {
    stop(sprintf("Missing power-result column(s): %s.", paste(missing, collapse = ", ")),
         call. = FALSE)
  }
  if (is.null(x.min)) {
    x.min <- min(df_power[[x.variable]], na.rm = TRUE)
  }
  if (is.null(x.max)) {
    x.max <- max(df_power[[x.variable]], na.rm = TRUE)
  }
  plot_data <- df_power
  plot_data$.sca_x <- plot_data[[x.variable]]
  plot_data$.sca_line <- as.factor(plot_data[[line.variable]])

  ggplot2::ggplot(
    plot_data,
    ggplot2::aes(x = .sca_x, y = power, colour = .sca_line, group = .sca_line)
  ) +
    ggplot2::geom_line(linewidth = 0.8) +
    ggplot2::geom_point(size = 1.8) +
    ggplot2::coord_cartesian(xlim = c(x.min, x.max), ylim = c(0, 1)) +
    ggplot2::labs(x = x.name, y = "Power", colour = line.name) +
    ggplot2::theme_minimal(base_size = 11)
}
