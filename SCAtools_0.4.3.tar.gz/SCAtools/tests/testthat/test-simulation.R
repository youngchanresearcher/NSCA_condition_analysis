test_that("random data retain logical and physical direction metadata", {
  set.seed(42)
  dat <- sca_random(20, intercepts = 0, slopes = 1, direction = "HH")
  expect_s3_class(dat, "data.frame")
  expect_equal(attr(dat, "sca_direction"), "HH")
  expect_equal(attr(dat, "empty_corner"), 4L)
  expect_true(all(dat$Y > dat$X))
})

test_that("power plotting validates its input", {
  expect_error(sca_powerplot(data.frame(n = 20)), "Missing power-result")
})

