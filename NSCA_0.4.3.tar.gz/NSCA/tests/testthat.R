library(testthat)
library(NSCA)

test_check("NSCA")
